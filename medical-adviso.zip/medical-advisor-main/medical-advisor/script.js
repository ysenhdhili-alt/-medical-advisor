/* ==========================================================
   MediAdvisor — GSAP animation layer (no jQuery)
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  if (typeof gsap === 'undefined') return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (typeof ScrollTrigger !== 'undefined') gsap.registerPlugin(ScrollTrigger);

  /* ---------------------------------------------------------
     1) Hero fade-in sequence (page load)
  --------------------------------------------------------- */
  const heroTimeline = gsap.timeline({ defaults: { ease: 'power3.out' } });
  const heroCopyTargets = [
    '.hero .eyebrow',
    '.hero__title',
    '.hero__sub',
    '.hero__cta',
    '.hero__trust',
  ];

  if (document.querySelector('.hero') && !reduceMotion) {
    heroTimeline
      .from(heroCopyTargets, { y: 26, opacity: 0, duration: 0.7, stagger: 0.12 })
      .from('.hero__visual .vital-card', { scale: 0.85, opacity: 0, duration: 0.6, stagger: 0.15 }, '-=0.4')
      .from('.hero__visual .med-icon', { scale: 0, opacity: 0, duration: 0.5, stagger: 0.1 }, '-=0.3')
      .from('.hero__visual .glow-orb', { opacity: 0, duration: 1 }, '-=0.6');
  } else if (document.querySelector('.hero')) {
    gsap.set([...heroCopyTargets, '.hero__visual *'], { opacity: 1 });
  }

  /* ---------------------------------------------------------
     2) Smooth scroll reveal for any [data-reveal] section
  --------------------------------------------------------- */
  const revealEls = document.querySelectorAll('[data-reveal]');
  revealEls.forEach((el) => {
    if (el.closest('.hero')) return; // hero handled by its own timeline
    if (reduceMotion) { gsap.set(el, { opacity: 1 }); return; }

    gsap.fromTo(
      el,
      { y: 40, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          once: true,
        },
      }
    );
  });

  /* ---------------------------------------------------------
     3) Form slide-up animation (consultation form)
  --------------------------------------------------------- */
  const form = document.querySelector('[data-reveal-form]');
  if (form && !reduceMotion) {
    gsap.fromTo(
      form,
      { y: 60, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.9,
        ease: 'power3.out',
        scrollTrigger: { trigger: form, start: 'top 88%', once: true },
      }
    );
  }

  /* ---------------------------------------------------------
     4) Magnetic button hover effect
  --------------------------------------------------------- */
  if (!reduceMotion && window.matchMedia('(pointer: fine)').matches) {
    document.querySelectorAll('.magnetic').forEach((btn) => {
      const strength = 0.35;

      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const relX = e.clientX - rect.left - rect.width / 2;
        const relY = e.clientY - rect.top - rect.height / 2;
        gsap.to(btn, { x: relX * strength, y: relY * strength, duration: 0.3, ease: 'power2.out' });
      });

      btn.addEventListener('mouseleave', () => {
        gsap.to(btn, { x: 0, y: 0, duration: 0.4, ease: 'elastic.out(1, 0.4)' });
      });
    });
  }

  /* ---------------------------------------------------------
     5) Card tilt effect ([data-tilt])
  --------------------------------------------------------- */
  if (!reduceMotion && window.matchMedia('(pointer: fine)').matches) {
    document.querySelectorAll('[data-tilt]').forEach((card) => {
      const maxTilt = 8;

      card.style.transformStyle = 'preserve-3d';

      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width;
        const py = (e.clientY - rect.top) / rect.height;
        const rotateX = (0.5 - py) * maxTilt;
        const rotateY = (px - 0.5) * maxTilt;

        gsap.to(card, {
          rotateX,
          rotateY,
          transformPerspective: 700,
          duration: 0.4,
          ease: 'power2.out',
        });
      });

      card.addEventListener('mouseleave', () => {
        gsap.to(card, { rotateX: 0, rotateY: 0, duration: 0.6, ease: 'power3.out' });
      });
    });
  }

  /* ---------------------------------------------------------
     6) Loading animation before AI response appears
        (consult form is a real POST submit, so we show an
        overlay immediately to bridge the navigation delay)
  --------------------------------------------------------- */
  const consultForm = document.getElementById('consultForm');
  if (consultForm) {
    const overlay = buildLoaderOverlay();
    document.body.appendChild(overlay);

    consultForm.addEventListener('submit', (e) => {
      if (!consultForm.checkValidity()) return; // let native validation show first
      overlay.classList.add('is-active');
      if (!reduceMotion) {
        gsap.to(overlay.querySelector('.ai-loader-pulse'), {
          boxShadow: '0 0 0 24px rgba(47,111,237,0)',
          scale: 1.15,
          duration: 1.1,
          repeat: -1,
          ease: 'power1.out',
        });
      }
    });
  }

  function buildLoaderOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ai-loader-overlay';
    overlay.innerHTML = `
      <div class="ai-loader-pulse"></div>
      <p>Analyzing your symptoms with your local AI model…</p>
    `;
    return overlay;
  }
});
