<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';

$pdo = getPDO();

// ---- Delete a record (POST + CSRF protected) -----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (!csrfVerify($_POST['csrf_token'] ?? null)) {
        $_SESSION['flash_error'] = 'Session expired — please try deleting again.';
    } else {
        $deleteId = (int) $_POST['delete_id'];
        $stmt = $pdo->prepare('DELETE FROM consultations WHERE id = :id');
        $stmt->execute([':id' => $deleteId]);
        $_SESSION['flash_success'] = 'Consultation record deleted.';
    }
    header('Location: history.php' . (isset($_GET['q']) ? '?q=' . urlencode($_GET['q']) : ''));
    exit;
}

$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashError   = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// ---- Search ----------------------------------------------------
$search = cleanInput($_GET['q'] ?? '');

// ---- Pagination --------------------------------------------------
$perPage = 6;
$page    = max(1, (int) ($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

if ($search !== '') {
    $countStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM consultations WHERE name LIKE :q OR symptoms LIKE :q'
    );
    $countStmt->execute([':q' => "%{$search}%"]);
    $total = (int) $countStmt->fetchColumn();

    $stmt = $pdo->prepare(
        'SELECT * FROM consultations
         WHERE name LIKE :q OR symptoms LIKE :q
         ORDER BY created_at DESC
         LIMIT :limit OFFSET :offset'
    );
    $stmt->bindValue(':q', "%{$search}%");
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $total = (int) $pdo->query('SELECT COUNT(*) FROM consultations')->fetchColumn();

    $stmt = $pdo->prepare(
        'SELECT * FROM consultations ORDER BY created_at DESC LIMIT :limit OFFSET :offset'
    );
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
}

$records    = $stmt->fetchAll();
$totalPages = max(1, (int) ceil($total / $perPage));
$token      = csrfToken();

function severityClass(string $severity): string
{
    return match ($severity) {
        'low'       => 'sev-low',
        'moderate'  => 'sev-moderate',
        'high'      => 'sev-high',
        'emergency' => 'sev-emergency',
        default     => 'sev-unknown',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Consultation History — MediAdvisor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="bg-aurora" aria-hidden="true"></div>

<header class="navbar">
  <div class="container navbar__inner">
    <a href="index.php" class="brand"><span class="brand__mark">+</span> MediAdvisor</a>
    <nav class="nav-links">
      <a href="index.php#consult">New consultation</a>
      <a href="history.php" class="is-active">History</a>
    </nav>
  </div>
</header>

<main class="history-page">
  <div class="container">

    <div class="history-head" data-reveal>
      <div>
        <span class="eyebrow">Your records</span>
        <h1 class="section-title">Consultation history</h1>
      </div>
      <form class="search-form" method="GET" action="history.php">
        <input type="search" name="q" placeholder="Search by name or symptom…" value="<?= h($search) ?>">
        <button type="submit" class="btn btn--ghost">Search</button>
      </form>
    </div>

    <?php if ($flashSuccess): ?><div class="alert alert--success" data-reveal><?= h($flashSuccess) ?></div><?php endif; ?>
    <?php if ($flashError): ?><div class="alert alert--error" data-reveal><?= h($flashError) ?></div><?php endif; ?>

    <?php if (empty($records)): ?>
      <div class="empty-state glass" data-reveal>
        <p>No consultations found<?= $search !== '' ? ' for "' . h($search) . '"' : '' ?>.</p>
        <a href="index.php#consult" class="btn btn--primary magnetic">Start your first consultation</a>
      </div>
    <?php else: ?>
      <div class="history-grid">
        <?php foreach ($records as $row): ?>
          <article class="history-card glass" data-reveal data-tilt>
            <div class="history-card__top">
              <h3><?= h($row['name']) ?> <span>· <?= h((string) $row['age']) ?>, <?= h($row['gender']) ?></span></h3>
              <span class="severity-badge <?= severityClass($row['severity']) ?>"><?= h(ucfirst($row['severity'])) ?></span>
            </div>
            <p class="history-card__symptoms"><strong>Symptoms:</strong> <?= h($row['symptoms']) ?></p>
            <p class="history-card__response"><strong>AI response:</strong> <?= h(mb_substr($row['response'], 0, 220)) ?><?= mb_strlen($row['response']) > 220 ? '…' : '' ?></p>
            <div class="history-card__bottom">
              <time><?= h(date('M j, Y · H:i', strtotime($row['created_at']))) ?></time>
              <form method="POST" action="history.php<?= $search !== '' ? '?q=' . urlencode($search) : '' ?>" onsubmit="return confirm('Delete this record permanently?');">
                <input type="hidden" name="csrf_token" value="<?= h($token) ?>">
                <input type="hidden" name="delete_id" value="<?= h((string) $row['id']) ?>">
                <button type="submit" class="btn btn--danger-text">Delete</button>
              </form>
            </div>
          </article>
        <?php endforeach; ?>
      </div>

      <?php if ($totalPages > 1): ?>
        <nav class="pagination" data-reveal>
          <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="history.php?page=<?= $p ?><?= $search !== '' ? '&q=' . urlencode($search) : '' ?>"
               class="<?= $p === $page ? 'is-active' : '' ?>"><?= $p ?></a>
          <?php endfor; ?>
        </nav>
      <?php endif; ?>
    <?php endif; ?>

  </div>
</main>

<footer class="footer">
  <div class="container footer__inner">
    <span>&copy; <?= date('Y') ?> MediAdvisor — Local AI, your data stays with you.</span>
    <span class="footer__disclaimer">Not a substitute for professional medical care.</span>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="script.js"></script>
</body>
</html>
