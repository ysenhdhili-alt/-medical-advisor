<?php
/**
 * ollama.php
 * ------------------------------------------------------------
 * Thin service layer around the local Ollama HTTP API.
 * No external/cloud AI calls — everything stays on localhost.
 * ------------------------------------------------------------
 */

declare(strict_types=1);

const OLLAMA_URL   = 'http://localhost:11434/api/generate';
const OLLAMA_MODEL = 'llama3'; // swap to "mistral" if you prefer that model
const OLLAMA_TIMEOUT_SECONDS = 60;

/**
 * Builds the safety-constrained prompt sent to the model.
 * Asks for strict JSON so advisor.php can render condition,
 * advice and severity as separate UI fields.
 */
function buildMedicalPrompt(array $data): string
{
    $name     = $data['name'];
    $age      = $data['age'];
    $gender   = $data['gender'];
    $symptoms = $data['symptoms'];
    $duration = $data['duration'];

    return <<<PROMPT
You are a cautious medical information assistant embedded in a website.
You are NOT a doctor and must never present yourself as one.

Patient context:
- Age: {$age}
- Gender: {$gender}
- Symptoms: {$symptoms}
- Duration of symptoms: {$duration}

Rules you must always follow:
1. Give only general, educational health information — never a definitive diagnosis.
2. Never prescribe or name specific drug dosages.
3. If symptoms sound serious or urgent (e.g. chest pain, breathing difficulty,
   severe bleeding, stroke signs), clearly say to seek emergency care immediately.
4. Always encourage seeing a licensed doctor for an actual diagnosis.
5. Keep tone calm, clear and supportive.

Respond with ONLY raw JSON (no markdown, no commentary, no code fences) using exactly
this shape:
{
  "possible_condition": "short plain-language description of possible general causes, not a certain diagnosis",
  "advice": "general self-care / next-step guidance in 2-4 sentences",
  "severity": "low" | "moderate" | "high" | "emergency",
  "disclaimer": "This is not a medical diagnosis. Please consult a licensed doctor for proper evaluation."
}
PROMPT;
}

/**
 * Sends a prompt to the local Ollama server and returns a
 * normalized array, regardless of whether the model returned
 * valid JSON.
 *
 * @return array{
 *   ok: bool,
 *   condition: string,
 *   advice: string,
 *   severity: string,
 *   disclaimer: string,
 *   raw: string,
 *   error: ?string
 * }
 */
function askOllama(string $prompt, string $model = OLLAMA_MODEL): array
{
    $payload = json_encode([
        'model'  => $model,
        'prompt' => $prompt,
        'stream' => false,
        'format' => 'json',
    ]);

    $ch = curl_init(OLLAMA_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => OLLAMA_TIMEOUT_SECONDS,
    ]);

    $body     = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $fallback = [
        'ok'         => false,
        'condition'  => 'Unable to reach the AI advisor',
        'advice'     => 'The AI advisor could not be reached. Please try again in a moment, and if the problem continues, contact a healthcare provider directly.',
        'severity'   => 'unknown',
        'disclaimer' => 'This is not a medical diagnosis. Please consult a licensed doctor for proper evaluation.',
        'raw'        => '',
        'error'      => null,
    ];

    if ($body === false || $curlErr) {
        $fallback['error'] = 'Could not connect to Ollama at ' . OLLAMA_URL .
            '. Make sure Ollama is running locally ("ollama serve") and the model "' .
            $model . '" is pulled ("ollama pull ' . $model . '"). Details: ' . $curlErr;
        return $fallback;
    }

    if ($httpCode !== 200) {
        $fallback['error'] = 'Ollama returned HTTP ' . $httpCode . '. Response: ' . substr((string) $body, 0, 300);
        return $fallback;
    }

    $decoded = json_decode((string) $body, true);
    if (!is_array($decoded) || !isset($decoded['response'])) {
        $fallback['error'] = 'Unexpected response shape from Ollama.';
        return $fallback;
    }

    $modelText = trim((string) $decoded['response']);
    $structured = json_decode($modelText, true);

    if (is_array($structured) && isset($structured['advice'])) {
        return [
            'ok'         => true,
            'condition'  => (string) ($structured['possible_condition'] ?? 'General assessment'),
            'advice'     => (string) ($structured['advice'] ?? ''),
            'severity'   => strtolower((string) ($structured['severity'] ?? 'unknown')),
            'disclaimer' => (string) ($structured['disclaimer'] ?? 'This is not a medical diagnosis. Please consult a licensed doctor for proper evaluation.'),
            'raw'        => $modelText,
            'error'      => null,
        ];
    }

    // Model didn't return clean JSON — fall back to showing the raw text as advice.
    return [
        'ok'         => true,
        'condition'  => 'General assessment',
        'advice'     => $modelText !== '' ? $modelText : 'No response generated. Please try again.',
        'severity'   => 'unknown',
        'disclaimer' => 'This is not a medical diagnosis. Please consult a licensed doctor for proper evaluation.',
        'raw'        => $modelText,
        'error'      => null,
    ];
}
