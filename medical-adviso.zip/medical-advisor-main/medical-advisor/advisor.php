<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/ollama.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// ---- Step 1 & 2: receive + validate input --------------------
if (!csrfVerify($_POST['csrf_token'] ?? null)) {
    $_SESSION['form_errors'] = ['Your session expired. Please submit the form again.'];
    header('Location: index.php#consult');
    exit;
}

$name     = cleanInput($_POST['name'] ?? '');
$ageRaw   = cleanInput($_POST['age'] ?? '');
$gender   = cleanInput($_POST['gender'] ?? '');
$symptoms = cleanInput($_POST['symptoms'] ?? '');
$duration = cleanInput($_POST['duration'] ?? '');

$errors = [];

if ($name === '' || mb_strlen($name) > 100) {
    $errors[] = 'Please enter a valid name.';
}
if (!ctype_digit($ageRaw) || (int) $ageRaw < 0 || (int) $ageRaw > 120) {
    $errors[] = 'Please enter a valid age between 0 and 120.';
}
if (!in_array($gender, ['Female', 'Male', 'Other', 'Prefer not to say'], true)) {
    $errors[] = 'Please select a gender option.';
}
$allowedDurations = ['Less than a day', '1–3 days', '4–7 days', 'More than a week', 'Chronic / ongoing'];
if (!in_array($duration, $allowedDurations, true)) {
    $errors[] = 'Please select how long you\'ve had these symptoms.';
}
if ($symptoms === '' || mb_strlen($symptoms) < 5) {
    $errors[] = 'Please describe your symptoms in a little more detail.';
} elseif (mb_strlen($symptoms) > 2000) {
    $errors[] = 'Symptom description is too long (max 2000 characters).';
}

if (!empty($errors)) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_old']    = compact('name', 'gender', 'duration', 'symptoms') + ['age' => $ageRaw];
    header('Location: index.php#consult');
    exit;
}

$age = (int) $ageRaw;

// ---- Step 3: send symptoms to Ollama AI ----------------------
$prompt = buildMedicalPrompt(compact('name', 'age', 'gender', 'symptoms', 'duration'));
$result = askOllama($prompt); // ---- Step 4 happens inside askOllama() (decode response)

// ---- Step 5: store result in MySQL ---------------------------
$saved   = false;
$saveErr = null;

try {
    $pdo = getPDO();
    $stmt = $pdo->prepare(
        'INSERT INTO consultations (name, age, gender, symptoms, duration, response, severity)
         VALUES (:name, :age, :gender, :symptoms, :duration, :response, :severity)'
    );
    $stmt->execute([
        ':name'     => $name,
        ':age'      => $age,
        ':gender'   => $gender,
        ':symptoms' => $symptoms,
        ':duration' => $duration,
        ':response' => $result['advice'] . ' || condition: ' . $result['condition'],
        ':severity' => $result['severity'],
    ]);
    $saved = true;
} catch (PDOException $e) {
    $saveErr = 'Your result was generated but could not be saved to history right now.';
}

$severityMeta = [
    'low'       => ['label' => 'Low',       'class' => 'sev-low'],
    'moderate'  => ['label' => 'Moderate',  'class' => 'sev-moderate'],
    'high'      => ['label' => 'High',      'class' => 'sev-high'],
    'emergency' => ['label' => 'Emergency', 'class' => 'sev-emergency'],
    'unknown'   => ['label' => 'Unknown',   'class' => 'sev-unknown'],
][$result['severity']] ?? ['label' => ucfirst($result['severity']), 'class' => 'sev-unknown'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Result — MediAdvisor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="bg-aurora" aria-hidden="true"></div>

<header class="navbar">
  <div class="container navbar__inner">
    <a href="index.php" class="brand"><span class="brand__mark">+</span> MediAdvisor</a>
    <nav class="nav-links">
      <a href="index.php#consult">New consultation</a>
      <a href="history.php">History</a>
    </nav>
  </div>
</header>

<main class="result-page">
  <div class="container result-page__inner">

    <?php if ($result['error']): ?>
      <div class="alert alert--error" data-reveal>
        <strong>Couldn't reach the local AI model.</strong>
        <p><?= h($result['error']) ?></p>
        <a href="index.php#consult" class="btn btn--ghost">Try again</a>
      </div>
    <?php endif; ?>

    <?php if ($saveErr): ?>
      <div class="alert alert--warn" data-reveal><?= h($saveErr) ?></div>
    <?php endif; ?>

    <div class="result-card glass" data-reveal data-tilt>
      <div class="result-card__top">
        <span class="eyebrow">AI guidance for <?= h($name) ?></span>
        <span class="severity-badge <?= h($severityMeta['class']) ?>"><?= h($severityMeta['label']) ?> severity</span>
      </div>

      <h1 class="result-card__condition"><?= h($result['condition']) ?></h1>

      <div class="result-card__section">
        <h2>Advice</h2>
        <p><?= nl2br(h($result['advice'])) ?></p>
      </div>

      <div class="result-card__meta">
        <div><span>Age</span><strong><?= h((string) $age) ?></strong></div>
        <div><span>Gender</span><strong><?= h($gender) ?></strong></div>
        <div><span>Duration</span><strong><?= h($duration) ?></strong></div>
      </div>

      <div class="result-card__symptoms">
        <span>You described:</span>
        <p>"<?= h($symptoms) ?>"</p>
      </div>

      <div class="disclaimer-box">
        ⚠️ <?= h($result['disclaimer']) ?> If symptoms are severe or you feel this is an emergency, contact emergency services immediately.
      </div>

      <div class="result-card__actions">
        <a href="index.php#consult" class="btn btn--primary magnetic">New consultation</a>
        <a href="history.php" class="btn btn--ghost">View history</a>
      </div>
    </div>
  </div>
</main>

<footer class="footer">
  <div class="container footer__inner">
    <span>&copy; <?= date('Y') ?> MediAdvisor — Local AI, your data stays with you.</span>
    <span class="footer__disclaimer">Not a substitute for professional medical care.</span>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="script.js"></script>
</body>
</html>
