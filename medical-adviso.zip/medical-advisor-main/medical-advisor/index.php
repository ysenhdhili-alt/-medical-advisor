<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';

$token = csrfToken();

// Surface validation errors / sticky values if redirected back from advisor.php
$errors = $_SESSION['form_errors'] ?? [];
$old    = $_SESSION['form_old'] ?? [];
unset($_SESSION['form_errors'], $_SESSION['form_old']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MediAdvisor — AI Health Companion</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="bg-aurora" aria-hidden="true"></div>

<header class="navbar">
  <div class="container navbar__inner">
    <a href="index.php" class="brand">
      <span class="brand__mark">+</span> MediAdvisor
    </a>
    <nav class="nav-links">
      <a href="index.php#consult">Get Advice</a>
      <a href="history.php">History</a>
      <a href="index.php#how">How it works</a>
    </nav>
    <a href="index.php#consult" class="btn btn--ghost nav-cta">Start Consultation</a>
  </div>
</header>

<main>

  <section class="hero">
    <div class="container hero__grid">
      <div class="hero__copy" data-reveal>
        <span class="eyebrow">Private &middot; Offline &middot; Local AI</span>
        <h1 class="hero__title">
          Understand your symptoms<br>
          before you <em>worry</em> about them.
        </h1>
        <p class="hero__sub">
          MediAdvisor runs a local AI model on your own machine to turn the
          symptoms you describe into clear, general guidance — no cloud,
          no data leaving your server.
        </p>
        <div class="hero__cta">
          <a href="#consult" class="btn btn--primary magnetic">Start free consultation</a>
          <a href="#how" class="btn btn--text">See how it works →</a>
        </div>
        <div class="hero__trust">
          <div class="trust__item"><strong>100%</strong><span>Local &amp; offline AI</span></div>
          <div class="trust__item"><strong>0</strong><span>Cloud API calls</span></div>
          <div class="trust__item"><strong>24/7</strong><span>Available on your server</span></div>
        </div>
      </div>

      <div class="hero__visual" data-reveal>
        <div class="vital-card vital-card--pulse floaty">
          <div class="vital-card__label">Heart rate</div>
          <svg viewBox="0 0 120 40" class="pulse-line"><polyline points="0,20 15,20 22,5 30,35 38,20 50,20 58,12 65,28 75,20 120,20"/></svg>
          <div class="vital-card__value">72 <span>bpm</span></div>
        </div>
        <div class="vital-card vital-card--temp floaty floaty--slow">
          <div class="vital-card__label">Temperature</div>
          <div class="vital-card__value">36.6 <span>&deg;C</span></div>
        </div>
        <div class="glow-orb" aria-hidden="true"></div>
        <div class="med-icon med-icon--1 floaty" aria-hidden="true">💊</div>
        <div class="med-icon med-icon--2 floaty floaty--slow" aria-hidden="true">🩺</div>
        <div class="med-icon med-icon--3 floaty" aria-hidden="true">🧬</div>
      </div>
    </div>
  </section>

  <section id="how" class="how" data-reveal>
    <div class="container">
      <span class="eyebrow eyebrow--center">How it works</span>
      <h2 class="section-title">Three steps to clarity</h2>
      <div class="how__grid">
        <div class="how__card glass" data-tilt>
          <span class="how__num">01</span>
          <h3>Describe your symptoms</h3>
          <p>Tell us what you're feeling, for how long, and a little about you.</p>
        </div>
        <div class="how__card glass" data-tilt>
          <span class="how__num">02</span>
          <h3>Local AI reasons it through</h3>
          <p>Your own Ollama model analyzes the input — entirely on your server.</p>
        </div>
        <div class="how__card glass" data-tilt>
          <span class="how__num">03</span>
          <h3>Get clear, safe guidance</h3>
          <p>Receive general advice, a severity read, and a saved record to revisit.</p>
        </div>
      </div>
    </div>
  </section>

  <section id="consult" class="consult" data-reveal>
    <div class="container consult__grid">
      <div class="consult__intro">
        <span class="eyebrow">Get advice</span>
        <h2 class="section-title">Tell us what's going on</h2>
        <p>This form is processed locally and stored only in your own database.
           It's not a substitute for a real medical visit.</p>
        <ul class="consult__list">
          <li>Takes under a minute</li>
          <li>Severity-aware AI response</li>
          <li>Saved to your consultation history</li>
        </ul>
      </div>

      <form class="consult__form glass" action="advisor.php" method="POST" id="consultForm" data-reveal-form>
        <input type="hidden" name="csrf_token" value="<?= h($token) ?>">

        <?php if (!empty($errors)): ?>
          <div class="alert alert--error">
            <ul>
              <?php foreach ($errors as $err): ?>
                <li><?= h($err) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <div class="form-row">
          <div class="form-group">
            <label for="name">Full name</label>
            <input type="text" id="name" name="name" maxlength="100" required
                   value="<?= h($old['name'] ?? '') ?>" placeholder="Jane Doe">
          </div>
          <div class="form-group form-group--sm">
            <label for="age">Age</label>
            <input type="number" id="age" name="age" min="0" max="120" required
                   value="<?= h($old['age'] ?? '') ?>" placeholder="29">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
              <option value="" disabled <?= empty($old['gender']) ? 'selected' : '' ?>>Select…</option>
              <?php foreach (['Female', 'Male', 'Other', 'Prefer not to say'] as $g): ?>
                <option value="<?= h($g) ?>" <?= (($old['gender'] ?? '') === $g) ? 'selected' : '' ?>><?= h($g) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="duration">Symptom duration</label>
            <select id="duration" name="duration" required>
              <option value="" disabled <?= empty($old['duration']) ? 'selected' : '' ?>>Select…</option>
              <?php foreach (['Less than a day', '1–3 days', '4–7 days', 'More than a week', 'Chronic / ongoing'] as $d): ?>
                <option value="<?= h($d) ?>" <?= (($old['duration'] ?? '') === $d) ? 'selected' : '' ?>><?= h($d) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="symptoms">Describe your symptoms</label>
          <textarea id="symptoms" name="symptoms" rows="4" required
                    placeholder="E.g. dull headache behind my eyes, mild fever, started yesterday evening…"><?= h($old['symptoms'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn btn--primary btn--block magnetic">
          Get AI guidance
        </button>
        <p class="form-disclaimer">
          By submitting, you agree this is general information only — not a diagnosis.
        </p>
      </form>
    </div>
  </section>

</main>

<footer class="footer">
  <div class="container footer__inner">
    <span>&copy; <?= date('Y') ?> MediAdvisor — Local AI, your data stays with you.</span>
    <span class="footer__disclaimer">Not a substitute for professional medical care.</span>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<script src="script.js"></script>
</body>
</html>
