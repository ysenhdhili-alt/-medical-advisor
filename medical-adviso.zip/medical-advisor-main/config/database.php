<?php
/**
 * config/database.php
 * ------------------------------------------------------------
 * PDO connection + shared security helpers used across the app.
 * Every page that talks to the database or needs session/CSRF
 * protection includes this file first.
 * ------------------------------------------------------------
 */

declare(strict_types=1);

// ---- Session (must start before any HTML output) -----------
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
    ]);
}

// ---- Database credentials -----------------------------------
// Update these to match your local MySQL / XAMPP setup.
const DB_HOST = '127.0.0.1';
const DB_NAME = 'medical_advisor';
const DB_USER = 'root';
const DB_PASS = '';
const DB_CHARSET = 'utf8mb4';

function getPDO(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('Database connection failed. Please check config/database.php and confirm the
                  "medical_advisor" database has been imported (see database.sql).');
        }
    }

    return $pdo;
}

// ---- Security helpers ----------------------------------------

/** Escape output for safe HTML rendering (XSS protection). */
function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Generate (or reuse) a CSRF token for the current session. */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Verify a submitted CSRF token against the session token. */
function csrfVerify(?string $token): bool
{
    return is_string($token)
        && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/** Trim + strip tags from raw POST/GET input. */
function cleanInput(?string $value): string
{
    return trim(strip_tags($value ?? ''));
}
